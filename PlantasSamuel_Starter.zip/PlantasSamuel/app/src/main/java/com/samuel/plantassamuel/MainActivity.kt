package com.samuel.plantassamuel

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                PlantasSamuelApp()
            }
        }
    }
}

@Composable
fun PlantasSamuelApp() {
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var selectedPlant by remember { mutableStateOf<Plant?>(null) }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Text(
                    text = "Catálogo de Plantas",
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(16.dp)
                )
                PlantGrid(
                    plants = samplePlants,
                    onSelect = { p ->
                        selectedPlant = p
                        scope.launch { drawerState.close() }
                    }
                )
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(selectedPlant?.name ?: "Aplicación de Samuel")
                    },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Default.Menu, contentDescription = "Menú")
                        }
                    }
                )
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (selectedPlant == null) {
                    HomeScreen()
                } else {
                    PlantDetailScreen(selectedPlant!!)
                }
            }
        }
    }
}

@Composable
fun HomeScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Aplicación de Samuel",
            fontSize = 32.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(12.dp))
        Text(
            text = "prueba 1",
            fontSize = 18.sp,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun PlantDetailScreen(plant: Plant) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Espacio central reservado para el modelo 3D
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(260.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "Espacio reservado para modelo 3D",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Spacer(Modifier.height(16.dp))

        // Dos columnas con factores y detalles de cuidado
        Row(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 8.dp)
            ) {
                Text(
                    "Factores clave",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(8.dp))
                plant.factors.forEach { f ->
                    Text("• " + f, style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(4.dp))
                }
            }
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(start = 8.dp)
            ) {
                Text(
                    "Detalles",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(8.dp))
                plant.details.forEach { (k, v) ->
                    Text(k + ": " + v, style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(4.dp))
                }
            }
        }
    }
}

@Composable
fun PlantGrid(plants: List<Plant>, onSelect: (Plant) -> Unit) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        content = {
            items(plants) { plant ->
                PlantCard(plant = plant, onClick = { onSelect(plant) })
            }
        }
    )
}

@Composable
fun PlantCard(plant: Plant, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable { onClick() }
            .padding(16.dp)
    ) {
        Text(
            text = plant.name,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = plant.shortHint,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

data class Plant(
    val name: String,
    val shortHint: String,
    val factors: List<String>,
    val details: Map<String, String>
)

val samplePlants = listOf(
    Plant(
        name = "Aloe vera",
        shortHint = "Riego bajo, mucha luz indirecta",
        factors = listOf(
            "Riego: escaso (dejar secar el sustrato)",
            "Luz: brillante indirecta",
            "Sustrato: bien drenado",
            "Temperatura: 18–26 °C"
        ),
        details = mapOf(
            "Frecuencia de riego" to "Cada 2–3 semanas",
            "Exposición" to "Luz intensa, evitar sol directo fuerte",
            "Maceta" to "Con buen drenaje",
            "Fertilizante" to "Ligero en primavera/verano"
        )
    ),
    Plant(
        name = "Monstera deliciosa",
        shortHint = "Riego moderado, luz media",
        factors = listOf(
            "Riego: moderado",
            "Luz: media a brillante indirecta",
            "Humedad: media-alta",
            "Temperatura: 20–28 °C"
        ),
        details = mapOf(
            "Frecuencia de riego" to "Semanal aprox.",
            "Exposición" to "Evitar sol directo",
            "Sustrato" to "Rico y aireado",
            "Fertilizante" to "Mensual en época de crecimiento"
        )
    ),
    Plant(
        name = "Ficus elastica",
        shortHint = "Luz brillante, riego moderado",
        factors = listOf(
            "Riego: moderado (no encharcar)",
            "Luz: brillante indirecta",
            "Humedad: media",
            "Temperatura: 18–27 °C"
        ),
        details = mapOf(
            "Frecuencia de riego" to "Cada 7–10 días",
            "Exposición" to "Cerca de ventana luminosa",
            "Poda" to "Ligera para controlar tamaño",
            "Fertilizante" to "Balanceado cada 4–6 semanas"
        )
    ),
    Plant(
        name = "Lavanda",
        shortHint = "Mucho sol, riego bajo",
        factors = listOf(
            "Riego: bajo",
            "Luz: sol directo",
            "Sustrato: arenoso y drenante",
            "Temperatura: 18–30 °C"
        ),
        details = mapOf(
            "Frecuencia de riego" to "Cuando el sustrato esté seco",
            "Exposición" to "Mínimo 6 h de sol",
            "Maceta" to "Drenaje excelente",
            "Poda" to "Después de floración"
        )
    ),
    Plant(
        name = "Cacto",
        shortHint = "Sol directo, riego muy bajo",
        factors = listOf(
            "Riego: muy bajo",
            "Luz: sol directo",
            "Sustrato: especial para cactus",
            "Temperatura: 20–35 °C"
        ),
        details = mapOf(
            "Frecuencia de riego" to "Cada 3–4 semanas",
            "Exposición" to "Sol pleno",
            "Maceta" to "Terracota con drenaje",
            "Fertilizante" to "Escaso, específico para cactus"
        )
    ),
    Plant(
        name = "Sansevieria (Lengua de suegra)",
        shortHint = "Muy resistente, poca agua",
        factors = listOf(
            "Riego: bajo",
            "Luz: baja a media, tolera brillante indirecta",
            "Humedad: baja",
            "Temperatura: 16–30 °C"
        ),
        details = mapOf(
            "Frecuencia de riego" to "Cada 2–3 semanas",
            "Exposición" to "Versátil, evita sol directo fuerte",
            "Sustrato" to "Drenaje alto",
            "Fertilizante" to "Ocasional en crecimiento"
        )
    )
)
